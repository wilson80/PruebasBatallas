/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AnimalesTier3;

import Tienda.Mascotas;

/**
 *
 * @author Jonwil
 */
public class Buho extends Mascotas{

    public Buho() {
        setNombreMascota("Buho   ");
        setUnidadesDeDanoInicial(5);
        setUnidadesDeVidaInicial(3);
        setTipos("volador,solitario");
        setTier(3);
        setDescripcionHabilidad("vacio");
        setNivel(1);
        setExperiencia(1);

    
    }
    
}
//27. Buho [5/3]
//○ Suerte amigos: Dar un amigo al azar (+2/+2)/ (+4/+4) / (+6/+6) al vender.
//○ Tipo volador/solitario