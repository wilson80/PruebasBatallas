/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AnimalesTier3;

import Tienda.Mascotas;

/**
 *
 * @author Jonwil
 */
public class Buey extends Mascotas{
        public Buey() {
        setNombreMascota("Buey   ");
        setUnidadesDeDanoInicial(1);
        setUnidadesDeVidaInicial(4);
        setTipos("mamifero");
        setTier(3);
        setDescripcionHabilidad("vacio");
        setNivel(1);
        setExperiencia(1);

    }
}
//25. Buey [1/4]
//○ Mejor me protejo: gana armadura de melón y +2/ +4/ + 6 ATK cuando la mascota aliada
//de delante se debilita.
//○ Tipo mamífero
