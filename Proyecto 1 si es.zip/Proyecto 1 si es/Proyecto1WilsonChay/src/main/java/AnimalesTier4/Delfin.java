/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AnimalesTier4;

import Tienda.Mascotas;

/**
 *
 * @author Jonwil
 */
public class Delfin extends Mascotas{
    public Delfin()  {
        setNombreMascota("Delfin ");
        setUnidadesDeDanoInicial(4);
        setUnidadesDeVidaInicial(6);
        setTipos("acuatico");
        setTier(4);
        setDescripcionHabilidad("vacio");
        setNivel(1);
        setExperiencia(1);

    }

}
//    31. Delfín [4/6]
//○ Salpicón: reparte 5/10/15 de daño al enemigo con la salud más baja al comenzar la
//batalla.
//○ Tipo: Acuático