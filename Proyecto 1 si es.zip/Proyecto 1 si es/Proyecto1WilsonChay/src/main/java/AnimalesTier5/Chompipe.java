/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AnimalesTier5;

import Tienda.Mascotas;

/**
 *
 * @author Jonwil
 */
public class Chompipe extends Mascotas{
        public Chompipe() {
        setNombreMascota("Chompi.");
        setUnidadesDeDanoInicial(3);
        setUnidadesDeVidaInicial(4);
        setTipos("terrestre,volador");
        setTier(5);
        setDescripcionHabilidad("vacio");
        setNivel(1);
        setExperiencia(1);

    }
}
//43. Chompipe: [3/4]
//○ Solidaridad: Le da (+3/+3) /(+6/+6)/(+9/+9) a un aliado invocado.
//○ Terrestre/Volador